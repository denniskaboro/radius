<div class="row">
    <!-- Pie Chart -->

    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-10" id="design">
        <!-- Basic Card Example -->
        <div class="card shadow mb-4 text-gray-900" style="padding: 30px;">
            <div class="card-header">
                <h5 class="m-0 font-weight-bold text-secondary"><?php echo $page; ?></h5>
            </div>
