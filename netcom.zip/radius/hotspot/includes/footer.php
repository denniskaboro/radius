</div>
</div>
<!--end page wrapper -->

<div class="col">
    <div class="modal fade" id="delete" tabindex="-1" aria-labelledby="logoutModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="logoutModalLabel">Confirm to Delete?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">Your data will be deleted. Are you sure you want to this?</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <a class="btn btn-sm btn-danger" id="del" href="">Delete</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!--start overlay-->
<div class="overlay toggle-icon"></div>
<!--end overlay-->
<!--Start Back To Top Button--> <a href="javaScript:;" class="back-to-top"><i class='bx bxs-up-arrow-alt'></i></a>
<!--End Back To Top Button-->
<footer class="page-footer">
    <p class="mb-0"> © NETCOM INTERNET 2023. All right reserved.</p>
</footer>

<script src="/hotspot/assets/js/bootstrap.bundle.min.js"></script>
<!--plugins-->

<script src="/hotspot/assets/plugins/simplebar/js/simplebar.min.js"></script>
<script src="/hotspot/assets/plugins/metismenu/js/metisMenu.min.js"></script>
<script src="/hotspot/assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
<script src="/hotspot/assets/plugins/chartjs/js/Chart.min.js"></script>
<script src="/hotspot/assets/plugins/chartjs/js/Chart.extension.js"></script>
<script src="/hotspot/assets/plugins/notifications/js/lobibox.min.js"></script>
<script src="/hotspot/assets/plugins/notifications/js/notifications.min.js"></script>
<!--app JS-->
<script src="/hotspot/assets/js/app.js"></script>

</body>

</html>