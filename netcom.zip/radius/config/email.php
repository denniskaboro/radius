<?php
$email_host = "smtp.gmail.com";
$email_user = "netcomwirelesss@gmail.com";
$email_pass = "fwipexlapqtulnuu";
$admin_email = "netcomwirelesss@gmail.com";
?>   
