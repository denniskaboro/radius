<?php include 'management.php'; ?>

<nav class="navbar navbar-inverse" style="background-color: rgba(41,47,64,0.79);">
    <div class="container-fluid">
        <ul class="nav navbar-nav">
            <li><a href="nas_list.php"><span class="glyphicon glyphicon-list"></span> NAS List</a></li>
            <li><a href="nas_create.php"><span class="glyphicon glyphicon-user"></span></span> Create NAS</a></li>
            <li><a href="nas_delete.php"><span class="glyphicon glyphicon-trash"></span> Delete NAS</a></li>

        </ul>
    </div>
</nav>
    
